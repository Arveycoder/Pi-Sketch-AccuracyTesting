import os
import cv2
import numpy as np
from flask import Flask, render_template, request, jsonify, send_from_directory
from werkzeug.utils import secure_filename
from skimage.metrics import structural_similarity as ssim
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
from matplotlib.figure import Figure
from matplotlib.backends.backend_agg import FigureCanvasAgg as FigureCanvas
from PIL import Image
import io
import base64

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload
app.config['STATIC_FOLDER'] = 'static'
app.config['RESULTS_FOLDER'] = 'static/results'

# Create necessary directories if they don't exist
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['RESULTS_FOLDER'], exist_ok=True)

def allowed_file(filename):
    # Allow any file with an extension - we'll handle format detection in the processing
    return '.' in filename

def extract_sketch_features(image_path):
    """Extract features specifically designed for sketch comparison"""
    try:
        print(f"Processing image: {image_path}")
        
        # Check if file exists
        if not os.path.exists(image_path):
            print(f"Error: File does not exist: {image_path}")
            return None
        
        # Try to read image with OpenCV first
        img = cv2.imread(image_path, cv2.IMREAD_COLOR)
        
        # If OpenCV fails, try with PIL for better format support
        if img is None:
            print(f"OpenCV failed to load {image_path}, trying PIL...")
            try:
                # Verify file exists and is readable
                if not os.path.isfile(image_path):
                    print(f"Error: File does not exist or is not a file: {image_path}")
                    return None
                
                # Try to open with PIL
                with Image.open(image_path) as pil_img:
                    print(f"PIL loaded image with mode: {pil_img.mode}, size: {pil_img.size}")
                    
                    # Ensure image has valid dimensions
                    if pil_img.size[0] == 0 or pil_img.size[1] == 0:
                        print(f"Error: Image has invalid dimensions: {pil_img.size}")
                        return None
                    
                    # Convert to RGB if needed (handles RGBA, P, L, etc.)
                    if pil_img.mode in ('RGBA', 'LA'):
                        print("Converting transparent image to RGB with white background")
                        # Create white background for transparent images
                        background = Image.new('RGB', pil_img.size, (255, 255, 255))
                        if pil_img.mode == 'RGBA':
                            background.paste(pil_img, mask=pil_img.split()[-1])
                        else:  # LA mode
                            background.paste(pil_img, mask=pil_img.split()[-1])
                        pil_img = background
                    elif pil_img.mode == 'P':
                        print("Converting palette image to RGB")
                        pil_img = pil_img.convert('RGB')
                    elif pil_img.mode == 'L':
                        print("Converting grayscale image to RGB")
                        pil_img = pil_img.convert('RGB')
                    elif pil_img.mode in ('CMYK', 'LAB', 'HSV'):
                        print(f"Converting {pil_img.mode} image to RGB")
                        pil_img = pil_img.convert('RGB')
                    elif pil_img.mode != 'RGB':
                        print(f"Converting {pil_img.mode} image to RGB")
                        pil_img = pil_img.convert('RGB')
                    
                    # Convert PIL to numpy array
                    img_array = np.array(pil_img)
                    
                    # Ensure we have a valid array
                    if img_array is None or img_array.size == 0:
                        print(f"Error: Failed to convert PIL image to numpy array")
                        return None
                    
                    # Convert RGB to BGR for OpenCV
                    if len(img_array.shape) == 3 and img_array.shape[2] == 3:
                        img = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
                    else:
                        print(f"Error: Unexpected image array shape: {img_array.shape}")
                        return None
                    
                    print(f"Successfully converted to OpenCV format: {img.shape}")
                
            except Exception as e:
                print(f"Error: Could not load image from {image_path}: {e}")
                import traceback
                traceback.print_exc()
                return None
        else:
            print(f"OpenCV successfully loaded image: {img.shape}")
        
        # Ensure we have a valid image
        if img is None:
            print(f"Error: Image is None after loading: {image_path}")
            return None
            
        if img.size == 0:
            print(f"Error: Image has zero size: {image_path}")
            return None
            
        # Check image dimensions
        if len(img.shape) < 2:
            print(f"Error: Invalid image dimensions: {img.shape}")
            return None
        
        # Resize to standard size for consistent comparison
        img = cv2.resize(img, (512, 512))  # Higher resolution for better sketch analysis
        
        # Convert to grayscale for sketch analysis
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        features = {}
        
        # 1. Edge detection - crucial for sketches
        edges = cv2.Canny(gray, 50, 150)
        features['edges'] = edges
        
        # 2. Contour analysis - important for sketch outlines
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        features['contour_count'] = len(contours)
        features['contour_areas'] = [cv2.contourArea(c) for c in contours if cv2.contourArea(c) > 100]
        
        # 3. Line detection using Hough transform
        lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold=50, minLineLength=30, maxLineGap=10)
        features['line_count'] = len(lines) if lines is not None else 0
        
        # 4. Intensity distribution - for shading analysis
        features['intensity_hist'] = cv2.calcHist([gray], [0], None, [256], [0, 256])
        cv2.normalize(features['intensity_hist'], features['intensity_hist'], 0, 1, cv2.NORM_MINMAX)
        
        # 5. Gradient magnitude - for stroke strength
        grad_x = cv2.Sobel(gray, cv2.CV_64F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(gray, cv2.CV_64F, 0, 1, ksize=3)
        gradient_magnitude = np.sqrt(grad_x**2 + grad_y**2)
        features['gradient_mean'] = np.mean(gradient_magnitude)
        features['gradient_std'] = np.std(gradient_magnitude)
        
        # 6. Texture analysis using Local Binary Pattern
        def calculate_lbp(image, radius=1, n_points=8):
            lbp = np.zeros_like(image, dtype=np.uint8)
            for i in range(radius, image.shape[0] - radius):
                for j in range(radius, image.shape[1] - radius):
                    center = image[i, j]
                    binary_value = 0
                    for k in range(n_points):
                        angle = 2 * np.pi * k / n_points
                        x = int(i + radius * np.cos(angle))
                        y = int(j + radius * np.sin(angle))
                        if 0 <= x < image.shape[0] and 0 <= y < image.shape[1]:
                            if image[x, y] >= center:
                                binary_value |= (1 << k)
                    lbp[i, j] = binary_value
            return lbp
        
        try:
            lbp = calculate_lbp(gray)
            features['texture_hist'] = cv2.calcHist([lbp], [0], None, [256], [0, 256])
            cv2.normalize(features['texture_hist'], features['texture_hist'], 0, 1, cv2.NORM_MINMAX)
        except Exception as e:
            print(f"Warning: LBP calculation failed: {e}")
            # Fallback to simple texture analysis
            features['texture_hist'] = cv2.calcHist([gray], [0], None, [256], [0, 256])
            cv2.normalize(features['texture_hist'], features['texture_hist'], 0, 1, cv2.NORM_MINMAX)
        
        # 7. Regional analysis - divide into 3x3 grid
        h, w = gray.shape
        features['regions'] = {}
        for i in range(3):
            for j in range(3):
                region_name = f'region_{i}_{j}'
                y1, y2 = i * h // 3, (i + 1) * h // 3
                x1, x2 = j * w // 3, (j + 1) * w // 3
                region = gray[y1:y2, x1:x2]
                
                features['regions'][region_name] = {
                    'mean_intensity': np.mean(region),
                    'std_intensity': np.std(region),
                    'edge_density': np.sum(edges[y1:y2, x1:x2]) / (region.size * 255)
                }
        
        return features
        
    except Exception as e:
        print(f"Error extracting sketch features: {e}")
        import traceback
        traceback.print_exc()
        return None

def calculate_sketch_similarity(original_features, sketch_features):
    """Calculate similarity metrics specifically for sketch comparison"""
    if original_features is None or sketch_features is None:
        print("Error: One or both feature sets are None")
        return None
    
    try:
        similarities = {}
        
        # 1. Edge similarity (most important for sketches)
        edge_similarity = ssim(original_features['edges'], sketch_features['edges'])
        similarities['edge_similarity'] = max(0, edge_similarity) * 100
        
        # 2. Intensity distribution similarity
        hist_similarity = cv2.compareHist(
            original_features['intensity_hist'],
            sketch_features['intensity_hist'],
            cv2.HISTCMP_CORREL
        )
        similarities['intensity_similarity'] = max(0, hist_similarity) * 100
        
        # 3. Texture similarity
        texture_similarity = cv2.compareHist(
            original_features['texture_hist'],
            sketch_features['texture_hist'],
            cv2.HISTCMP_CORREL
        )
        similarities['texture_similarity'] = max(0, texture_similarity) * 100
        
        # 4. Structural similarity (contours and lines)
        contour_ratio = min(
            len(sketch_features['contour_areas']) / max(len(original_features['contour_areas']), 1),
            len(original_features['contour_areas']) / max(len(sketch_features['contour_areas']), 1)
        )
        similarities['structure_similarity'] = contour_ratio * 100
        
        # 5. Gradient similarity (stroke strength)
        grad_diff = abs(original_features['gradient_mean'] - sketch_features['gradient_mean'])
        max_grad = max(original_features['gradient_mean'], sketch_features['gradient_mean'])
        gradient_similarity = (1 - grad_diff / max(max_grad, 1)) * 100
        similarities['gradient_similarity'] = max(0, gradient_similarity)
        
        # 6. Regional similarity
        regional_similarities = []
        for region_name in original_features['regions']:
            if region_name in sketch_features['regions']:
                orig_region = original_features['regions'][region_name]
                sketch_region = sketch_features['regions'][region_name]
                
                intensity_sim = 1 - abs(orig_region['mean_intensity'] - sketch_region['mean_intensity']) / 255
                edge_sim = 1 - abs(orig_region['edge_density'] - sketch_region['edge_density'])
                
                regional_similarities.append((intensity_sim + edge_sim) / 2 * 100)
        
        similarities['regional_similarity'] = np.mean(regional_similarities) if regional_similarities else 0
        
        # Calculate overall similarity with weights appropriate for sketches
        weights = {
            'edge_similarity': 0.35,      # Edges are most important for sketches
            'structure_similarity': 0.25,  # Overall structure
            'intensity_similarity': 0.15,  # Shading and tones
            'texture_similarity': 0.10,    # Drawing texture
            'gradient_similarity': 0.10,   # Stroke strength
            'regional_similarity': 0.05    # Regional consistency
        }
    
        overall_similarity = sum(similarities[key] * weights[key] for key in weights.keys())
        similarities['overall_similarity'] = overall_similarity
        
        return similarities
    
    except Exception as e:
        print(f"Error in calculate_sketch_similarity: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def generate_sketch_visualization(original_path, sketch_path, similarities, output_path):
    """Generate visualization focused on sketch comparison"""
    # Load images with robust handling
    def load_image_robust(path):
        print(f"Loading image for visualization: {path}")
        
        if not os.path.exists(path):
            print(f"Error: File does not exist: {path}")
            return None
            
        img = cv2.imread(path, cv2.IMREAD_COLOR)
        if img is None:
            print(f"OpenCV failed to load {path}, trying PIL...")
            try:
                pil_img = Image.open(path)
                print(f"PIL loaded image with mode: {pil_img.mode}, size: {pil_img.size}")
                
                if pil_img.mode in ('RGBA', 'LA'):
                    print("Converting transparent image to RGB with white background")
                    background = Image.new('RGB', pil_img.size, (255, 255, 255))
                    if pil_img.mode == 'RGBA':
                        background.paste(pil_img, mask=pil_img.split()[-1])
                    else:
                        background.paste(pil_img, mask=pil_img.split()[-1])
                    pil_img = background
                elif pil_img.mode == 'P':
                    print("Converting palette image to RGB")
                    pil_img = pil_img.convert('RGB')
                elif pil_img.mode == 'L':
                    print("Converting grayscale image to RGB")
                    pil_img = pil_img.convert('RGB')
                elif pil_img.mode != 'RGB':
                    print(f"Converting {pil_img.mode} image to RGB")
                    pil_img = pil_img.convert('RGB')
                    
                img_array = np.array(pil_img)
                img = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
                print(f"Successfully converted to OpenCV format: {img.shape}")
            except Exception as e:
                print(f"Error loading image {path}: {e}")
                import traceback
                traceback.print_exc()
                return None
        else:
            print(f"OpenCV successfully loaded image: {img.shape}")
            
        return img
    
    original = load_image_robust(original_path)
    sketch = load_image_robust(sketch_path)
    
    if original is None or sketch is None:
        raise ValueError("Failed to load one or both images")
    
    # Create figure with subplots
    fig = Figure(figsize=(15, 10))
    canvas = FigureCanvas(fig)
    
    # Create a 2x3 grid for comprehensive visualization
    ax1 = fig.add_subplot(2, 3, 1)
    ax2 = fig.add_subplot(2, 3, 2)
    ax3 = fig.add_subplot(2, 3, 3)
    ax4 = fig.add_subplot(2, 3, 4)
    ax5 = fig.add_subplot(2, 3, 5)
    ax6 = fig.add_subplot(2, 3, 6)
    
    # Convert images to RGB for matplotlib
    original_rgb = cv2.cvtColor(original, cv2.COLOR_BGR2RGB)
    sketch_rgb = cv2.cvtColor(sketch, cv2.COLOR_BGR2RGB)
    
    # Plot original and sketch
    ax1.imshow(original_rgb)
    ax1.set_title('Original Photo', fontsize=12, fontweight='bold')
    ax1.axis('off')
    
    ax2.imshow(sketch_rgb)
    ax2.set_title('Sketch', fontsize=12, fontweight='bold')
    ax2.axis('off')
    
    # Edge comparison
    original_gray = cv2.cvtColor(original, cv2.COLOR_BGR2GRAY)
    sketch_gray = cv2.cvtColor(sketch, cv2.COLOR_BGR2GRAY)
    original_edges = cv2.Canny(cv2.resize(original_gray, (512, 512)), 50, 150)
    sketch_edges = cv2.Canny(cv2.resize(sketch_gray, (512, 512)), 50, 150)
    
    ax3.imshow(original_edges, cmap='gray')
    ax3.set_title('Original Edges', fontsize=12, fontweight='bold')
    ax3.axis('off')
    
    ax4.imshow(sketch_edges, cmap='gray')
    ax4.set_title('Sketch Edges', fontsize=12, fontweight='bold')
    ax4.axis('off')
    
    # Similarity metrics bar chart
    metrics = ['Overall', 'Edges', 'Structure', 'Intensity', 'Texture', 'Regional']
    values = [
        similarities['overall_similarity'],
        similarities['edge_similarity'],
        similarities['structure_similarity'],
        similarities['intensity_similarity'],
        similarities['texture_similarity'],
        similarities['regional_similarity']
    ]
    
    colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D', '#592E83', '#1B998B']
    bars = ax5.bar(metrics, values, color=colors)
    
    # Add value labels on bars
    for bar in bars:
        height = bar.get_height()
        ax5.text(bar.get_x() + bar.get_width()/2., height + 1,
                f'{height:.1f}%', ha='center', va='bottom', fontweight='bold')
    
    ax5.set_ylim(0, 105)
    ax5.set_ylabel('Similarity (%)', fontweight='bold')
    ax5.set_title('Sketch Similarity Metrics', fontsize=12, fontweight='bold')
    ax5.grid(axis='y', linestyle='--', alpha=0.7)
    plt.setp(ax5.get_xticklabels(), rotation=45, ha='right')
    
    # Overall similarity gauge
    overall_score = similarities['overall_similarity']
    
    # Create a simple gauge visualization
    theta = np.linspace(0, np.pi, 100)
    r = np.ones_like(theta)
    
    # Color based on score
    if overall_score >= 80:
        gauge_color = '#2E8B57'  # Green
    elif overall_score >= 60:
        gauge_color = '#FFD700'  # Yellow
    elif overall_score >= 40:
        gauge_color = '#FF8C00'  # Orange
    else:
        gauge_color = '#DC143C'  # Red
    
    ax6.fill_between(theta, 0, r, alpha=0.3, color='lightgray')
    
    # Fill gauge based on score
    score_theta = theta[:int(overall_score)]
    score_r = r[:int(overall_score)]
    ax6.fill_between(score_theta, 0, score_r, alpha=0.8, color=gauge_color)
    
    ax6.set_ylim(0, 1.2)
    ax6.set_xlim(0, np.pi)
    ax6.set_title(f'Overall Similarity: {overall_score:.1f}%', 
                  fontsize=14, fontweight='bold')
    ax6.text(np.pi/2, 0.5, f'{overall_score:.1f}%', 
             ha='center', va='center', fontsize=20, fontweight='bold')
    ax6.axis('off')
    
    # Adjust layout
    fig.tight_layout()
    
    # Save visualization
    fig.savefig(output_path, dpi=100, bbox_inches='tight')
    plt.close(fig)
    
    return output_path

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    if 'original' not in request.files or 'sketch' not in request.files:
        return jsonify({'error': 'Both original photo and sketch are required'}), 400
    
    original_file = request.files['original']
    sketch_file = request.files['sketch']
    
    if original_file.filename == '' or sketch_file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not (allowed_file(original_file.filename) and allowed_file(sketch_file.filename)):
        return jsonify({'error': 'Please select valid image files'}), 400
    
    # Save files with proper extensions
    original_filename = secure_filename(original_file.filename)
    sketch_filename = secure_filename(sketch_file.filename)
    
    # Get file extensions
    original_ext = os.path.splitext(original_filename)[1].lower()
    sketch_ext = os.path.splitext(sketch_filename)[1].lower()
    
    # Use original extensions or default to .jpg
    if not original_ext:
        original_ext = '.jpg'
    if not sketch_ext:
        sketch_ext = '.jpg'
    
    original_path = os.path.join(app.config['UPLOAD_FOLDER'], f'original{original_ext}')
    sketch_path = os.path.join(app.config['UPLOAD_FOLDER'], f'sketch{sketch_ext}')
    
    print(f"Saving original file to: {original_path}")
    print(f"Saving sketch file to: {sketch_path}")
    
    original_file.save(original_path)
    sketch_file.save(sketch_path)
    
    try:
        # Extract sketch-specific features
        original_features = extract_sketch_features(original_path)
        sketch_features = extract_sketch_features(sketch_path)
        
        if original_features is None or sketch_features is None:
            return jsonify({'error': 'Failed to process one or both images. Please ensure they are valid image files.'}), 400
        
        # Calculate sketch similarity
        similarities = calculate_sketch_similarity(original_features, sketch_features)
        
        if similarities is None:
            return jsonify({'error': 'Failed to calculate similarity metrics'}), 400
        
        # Generate visualization
        visualization_path = generate_sketch_visualization(
            original_path, 
            sketch_path, 
            similarities,
            os.path.join(app.config['RESULTS_FOLDER'], 'comparison.png')
        )
        
        # Prepare response
        response = {
            'overall_similarity': similarities['overall_similarity'],
            'detailed_metrics': {
                'edge_similarity': similarities['edge_similarity'],
                'structure_similarity': similarities['structure_similarity'],
                'intensity_similarity': similarities['intensity_similarity'],
                'texture_similarity': similarities['texture_similarity'],
                'gradient_similarity': similarities['gradient_similarity'],
                'regional_similarity': similarities['regional_similarity']
            },
            'visualization_path': visualization_path.replace('\\', '/'),
            'interpretation': get_similarity_interpretation(similarities['overall_similarity'])
        }
        
        return jsonify(response)
    
    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"Analysis error: {str(e)}")
        print(f"Error details: {error_details}")
        return jsonify({
            'error': f'Analysis failed: {str(e)}',
            'details': error_details if app.debug else 'Enable debug mode for detailed error information'
        }), 500

def get_similarity_interpretation(score):
    """Provide interpretation of similarity score for sketches"""
    if score >= 85:
        return "Excellent sketch! Very high similarity to the original photo."
    elif score >= 70:
        return "Good sketch with strong resemblance to the original."
    elif score >= 55:
        return "Decent sketch that captures main features of the original."
    elif score >= 40:
        return "Basic sketch with some recognizable elements."
    else:
        return "Sketch shows limited similarity to the original photo."

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/results/<filename>')
def result_file(filename):
    return send_from_directory(app.config['RESULTS_FOLDER'], filename)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)