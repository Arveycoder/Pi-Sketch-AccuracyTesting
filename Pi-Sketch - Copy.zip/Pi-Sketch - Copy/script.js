
const featureOptions = {
  "Hair Type": {
    "Bald": ["Buzz", "Zero Hair"],
    "Straight": ["Short", "Medium", "Long"],
    "Wavy": ["Short", "Medium", "Long"],
    "Curly": ["Short", "Medium", "Long"],
    "Coily": ["Short", "Medium", "Long"]
  },
  "Face Shape": ["Oval", "Round", "Square"],
  "Eye Shape": ["Almond", "Round", "Monolid"]
};

// Page 1 → Page 2
function goToPage2(feature) {
  currentFeature = feature;
  const subOptions = Object.keys(featureOptions[feature]);
  const page2List = document.getElementById("page2-options");
  document.getElementById("page2-title").textContent = feature;

  page2List.innerHTML = subOptions.map(option =>
    <li><button onclick="goToPage3('${option}')">${option}</button></li>
  ).join("");

  showSidebarPage(2);
}

// Page 2 → Page 3
function goToPage3(subOption) {
  const finalOptions = featureOptions[currentFeature][subOption];
  const page3List = document.getElementById("page3-options");
  document.getElementById("page3-title").textContent = subOption;

  page3List.innerHTML = finalOptions.map(option =>
    <li><button onclick="selectFinalOption('${option}')">${option}</button></li>
  ).join("");

  showSidebarPage(3);
}

// Final selection
function selectFinalOption(option) {
  alert(You selected: ${option});
  // Optional: save to selectedFeatures object
  goBackTo(1); // Go back to main menu
}

// For Face Shape or Eye Shape (1-level only)
function goToFinalOptions(feature) {
  const options = featureOptions[feature];
  const page3List = document.getElementById("page3-options");
  document.getElementById("page3-title").textContent = feature;

  page3List.innerHTML = options.map(option =>
    <li><button onclick="selectFinalOption('${option}')">${option}</button></li>
  ).join("");

  showSidebarPage(3);
}

// Show specific sidebar page
function showSidebarPage(pageNum) {
  document.querySelectorAll(".sidebar-page").forEach(page => page.style.display = "none");
  document.getElementById(sidebar-page-${pageNum}).style.display = "block";
}

// Back Navigation
function goBackTo(pageNum) {
  showSidebarPage(pageNum);
}