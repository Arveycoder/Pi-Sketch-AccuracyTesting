// Police Sketch Database - Local Images
const sketchDatabase = {
  male: {
    "Face Shape": {
      "Square": "Face Sketch Elements/head/01.png",
      "Rectangle": "Face Sketch Elements/head/02.png", 
      "Heart": "Face Sketch Elements/head/03.png",
      "Diamond": "Face Sketch Elements/head/04.png",
      "Triangle": "Face Sketch Elements/head/05.png",
      "Oblong": "Face Sketch Elements/head/06.png",
      "Inverted Triangle": "Face Sketch Elements/head/07.png",
      "Pearl": "Face Sketch Elements/head/08.png",
      "Round": "Face Sketch Elements/head/09.png",
      "Oval": "Face Sketch Elements/head/10.png"
    },
    "Hair Type": {
      "Bald": "Face Sketch Elements/head/01.png",
      "Straight": "Face Sketch Elements/hair/01.png",
      "Wavy": "Face Sketch Elements/hair/02.png",
      "Curly": "Face Sketch Elements/hair/03.png",
      "Coily": "Face Sketch Elements/hair/04.png",
      "Short": "Face Sketch Elements/hair/05.png",
      "Medium": "Face Sketch Elements/hair/06.png",
      "Long": "Face Sketch Elements/hair/07.png",
      "Buzz Cut": "Face Sketch Elements/hair/08.png",
      "Crew Cut": "Face Sketch Elements/hair/09.png",
      "Pompadour": "Face Sketch Elements/hair/10.png",
      "Undercut": "Face Sketch Elements/hair/11.png"
    },
    "Eye Shape": {
      "Almond": "Face Sketch Elements/eyes/01.png",
      "Round": "Face Sketch Elements/eyes/02.png",
      "Monolid": "Face Sketch Elements/eyes/03.png",
      "Hooded": "Face Sketch Elements/eyes/04.png",
      "Upturned": "Face Sketch Elements/eyes/05.png",
      "Down Turned": "Face Sketch Elements/eyes/06.png",
      "Close Set": "Face Sketch Elements/eyes/07.png",
      "Wide Set": "Face Sketch Elements/eyes/08.png",
      "Deep Set": "Face Sketch Elements/eyes/09.png",
      "Protruding": "Face Sketch Elements/eyes/10.png",
      "Small": "Face Sketch Elements/eyes/11.png",
      "Large": "Face Sketch Elements/eyes/12.png"
    },
    "Eyebrows": {
      "Thick": "Face Sketch Elements/eyebrows/01.png",
      "Thin": "Face Sketch Elements/eyebrows/02.png",
      "Arched": "Face Sketch Elements/eyebrows/03.png",
      "Straight": "Face Sketch Elements/eyebrows/04.png",
      "Bushy": "Face Sketch Elements/eyebrows/05.png",
      "Sparse": "Face Sketch Elements/eyebrows/06.png",
      "Unibrow": "Face Sketch Elements/eyebrows/07.png",
      "High Arch": "Face Sketch Elements/eyebrows/08.png",
      "Low Arch": "Face Sketch Elements/eyebrows/09.png",
      "Angular": "Face Sketch Elements/eyebrows/10.png",
      "Rounded": "Face Sketch Elements/eyebrows/11.png",
      "Flat": "Face Sketch Elements/eyebrows/12.png"
    },
    "Nose Shape": {
      "Roman": "Face Sketch Elements/nose/01.png",
      "Greek": "Face Sketch Elements/nose/02.png",
      "Nubian": "Face Sketch Elements/nose/03.png",
      "Hawk": "Face Sketch Elements/nose/04.png",
      "Snub": "Face Sketch Elements/nose/05.png",
      "Bulbous": "Face Sketch Elements/nose/06.png",
      "Hooked": "Face Sketch Elements/nose/07.png",
      "Flat": "Face Sketch Elements/nose/08.png",
      "Upturned": "Face Sketch Elements/nose/09.png",
      "Aquiline": "Face Sketch Elements/nose/10.png",
      "Button": "Face Sketch Elements/nose/11.png",
      "Crooked": "Face Sketch Elements/nose/12.png"
    },
    "Lip Shape": {
      "Full": "Face Sketch Elements/lips/01.png",
      "Thin": "Face Sketch Elements/lips/02.png",
      "Round": "Face Sketch Elements/lips/03.png",
      "Heart Shaped": "Face Sketch Elements/lips/04.png",
      "Bow Shaped": "Face Sketch Elements/lips/05.png",
      "Wide": "Face Sketch Elements/lips/06.png",
      "Down Turned": "Face Sketch Elements/lips/07.png",
      "Upturned": "Face Sketch Elements/lips/08.png",
      "Uneven": "Face Sketch Elements/lips/09.png",
      "Top Heavy": "Face Sketch Elements/lips/10.png",
      "Bottom Heavy": "Face Sketch Elements/lips/11.png",
      "Cupid's Bow": "Face Sketch Elements/lips/12.png"
    },
    "Facial Hair": {
      "Full Beard": "Face Sketch Elements/mustach/01.png",
      "Goatee": "Face Sketch Elements/mustach/02.png",
      "Mustache": "Face Sketch Elements/mustach/03.png",
      "Soul Patch": "Face Sketch Elements/mustach/04.png",
      "Stubble": "Face Sketch Elements/mustach/05.png",
      "Van Dyke": "Face Sketch Elements/mustach/06.png",
      "Handlebar": "Face Sketch Elements/mustach/07.png",
      "Horseshoe": "Face Sketch Elements/mustach/08.png",
      "Pencil": "Face Sketch Elements/mustach/09.png",
      "Walrus": "Face Sketch Elements/mustach/10.png",
      "Chevron": "Face Sketch Elements/mustach/11.png",
      "Fu Manchu": "Face Sketch Elements/mustach/12.png"
    },
    "Accessories": {
      "Glasses": "Face Sketch Elements/more/01.png",
      "Sunglasses": "Face Sketch Elements/more/02.png",
      "Hat": "Face Sketch Elements/more/03.png",
      "Cap": "Face Sketch Elements/more/04.png",
      "Bandana": "Face Sketch Elements/more/05.png",
      "Headband": "Face Sketch Elements/more/06.png"
    }
  },
  female: {
    "Face Shape": {
      "Square": "Face Sketch Elements/head/Group 2.png",
      "Rectangle": "Face Sketch Elements/head/Group 3.png", 
      "Heart": "Face Sketch Elements/head/Group 4.png",
      "Diamond": "Face Sketch Elements/head/Group 5.png",
      "Triangle": "Face Sketch Elements/head/Group 6.png",
      "Oblong": "Face Sketch Elements/head/Group 7.png",
      "Inverted Triangle": "Face Sketch Elements/head/Group 8.png",
      "Pearl": "Face Sketch Elements/head/Group 9.png",
      "Round": "Face Sketch Elements/head/Group 10.png",
      "Oval": "Face Sketch Elements/head/01.png"
    },
    "Hair Type": {
      "Bald": "Face Sketch Elements/head/Group 2.png",
      "Straight": "Face Sketch Elements/hair/Group 17.png",
      "Wavy": "Face Sketch Elements/hair/Group 18.png",
      "Curly": "Face Sketch Elements/hair/Group 19.png",
      "Coily": "Face Sketch Elements/hair/Group 20.png",
      "Bob": "Face Sketch Elements/hair/Group 21.png",
      "Pixie": "Face Sketch Elements/hair/Group 22.png",
      "Long": "Face Sketch Elements/hair/Group 23.png",
      "Bangs": "Face Sketch Elements/hair/Group 24.png",
      "Ponytail": "Face Sketch Elements/hair/Group 25.png",
      "Bun": "Face Sketch Elements/hair/Group 26.png",
      "Braids": "Face Sketch Elements/hair/Group 27.png"
    },
    "Eye Shape": {
      "Almond": "Face Sketch Elements/eyes/Group 29.png",
      "Round": "Face Sketch Elements/eyes/Group 30.png",
      "Monolid": "Face Sketch Elements/eyes/Group 31.png",
      "Hooded": "Face Sketch Elements/eyes/Group 32.png",
      "Upturned": "Face Sketch Elements/eyes/Group 33.png",
      "Down Turned": "Face Sketch Elements/eyes/Group 34.png",
      "Close Set": "Face Sketch Elements/eyes/Group 35.png",
      "Wide Set": "Face Sketch Elements/eyes/Group 36.png",
      "Deep Set": "Face Sketch Elements/eyes/Group 37.png",
      "Protruding": "Face Sketch Elements/eyes/Group 38.png",
      "Small": "Face Sketch Elements/eyes/Group 39.png",
      "Large": "Face Sketch Elements/eyes/Group 40.png"
    },
    "Eyebrows": {
      "Thick": "Face Sketch Elements/eyebrows/Group 41.png",
      "Thin": "Face Sketch Elements/eyebrows/Group 42.png",
      "Arched": "Face Sketch Elements/eyebrows/Group 43.png",
      "Straight": "Face Sketch Elements/eyebrows/Group 44.png",
      "Bushy": "Face Sketch Elements/eyebrows/Group 45.png",
      "Sparse": "Face Sketch Elements/eyebrows/Group 46.png",
      "High Arch": "Face Sketch Elements/eyebrows/Group 47.png",
      "Low Arch": "Face Sketch Elements/eyebrows/Group 48.png",
      "Angular": "Face Sketch Elements/eyebrows/Group 49.png",
      "Rounded": "Face Sketch Elements/eyebrows/Group 50.png",
      "Flat": "Face Sketch Elements/eyebrows/Group 51.png",
      "Feathered": "Face Sketch Elements/eyebrows/Group 52.png"
    },
    "Nose Shape": {
      "Roman": "Face Sketch Elements/nose/Group 53.png",
      "Greek": "Face Sketch Elements/nose/Group 54.png",
      "Nubian": "Face Sketch Elements/nose/Group 55.png",
      "Hawk": "Face Sketch Elements/nose/Group 56.png",
      "Snub": "Face Sketch Elements/nose/Group 57.png",
      "Bulbous": "Face Sketch Elements/nose/Group 58.png",
      "Hooked": "Face Sketch Elements/nose/Group 59.png",
      "Flat": "Face Sketch Elements/nose/Group 60.png",
      "Upturned": "Face Sketch Elements/nose/Group 61.png",
      "Aquiline": "Face Sketch Elements/nose/Group 62.png",
      "Button": "Face Sketch Elements/nose/Group 63.png",
      "Straight": "Face Sketch Elements/nose/Group 64.png"
    },
    "Lip Shape": {
      "Full": "Face Sketch Elements/lips/Group 65.png",
      "Thin": "Face Sketch Elements/lips/Group 66.png",
      "Round": "Face Sketch Elements/lips/Group 67.png",
      "Heart Shaped": "Face Sketch Elements/lips/Group 68.png",
      "Bow Shaped": "Face Sketch Elements/lips/Group 69.png",
      "Wide": "Face Sketch Elements/lips/Group 70.png",
      "Down Turned": "Face Sketch Elements/lips/Group 71.png",
      "Upturned": "Face Sketch Elements/lips/Group 72.png",
      "Uneven": "Face Sketch Elements/lips/Group 73.png",
      "Top Heavy": "Face Sketch Elements/lips/Group 74.png",
      "Bottom Heavy": "Face Sketch Elements/lips/Group 75.png",
      "Cupid's Bow": "Face Sketch Elements/lips/Group 76.png"
    },
    "Facial Hair": {
      "None": "Face Sketch Elements/head/Group 2.png",
      "Light Mustache": "Face Sketch Elements/mustach/Group 77.png",
      "Peach Fuzz": "Face Sketch Elements/mustach/Group 78.png"
    },
    "Accessories": {
      "Glasses": "Face Sketch Elements/more/Group 11.png",
      "Sunglasses": "Face Sketch Elements/more/Group 12.png",
      "Earrings": "Face Sketch Elements/more/Group 13.png",
      "Headband": "Face Sketch Elements/more/Group 14.png",
      "Hair Clip": "Face Sketch Elements/more/Group 15.png",
      "Necklace": "Face Sketch Elements/more/Group 16.png"
    }
  }
};

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = sketchDatabase;
}
